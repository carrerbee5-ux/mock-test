/**
 * Complete ready-to-use production Flutter Dart source code files
 * to export directly into an Android Studio Flutter project.
 */

export interface DartFileInfo {
  path: string;
  language: string;
  content: string;
  description: string;
}

export const flutterProjectFiles: Record<string, DartFileInfo> = {
  "pubspec": {
    path: "pubspec.yaml",
    language: "yaml",
    description: "The project dependencies configuration introducing modern Material 3, Google Fonts, and Provider state management.",
    content: `name: flutter_mock_test_app
description: "A premium Flutter Mock Test & Live Exam Application."
version: 1.0.0+1

environment:
  sdk: ">=3.0.0 <4.0.0"

dependencies:
  flutter:
    sdk: flutter
  
  # State Management
  provider: ^6.1.1
  
  # Google Fonts for modern typography
  google_fonts: ^6.1.0
  
  # Perfect icons
  flutter_svg: ^2.0.10+1
  
  # Firebase Core & Firebase Auth (Simulated and outlined for seamless real integration)
  firebase_core: ^2.27.0
  firebase_auth: ^4.17.8
  google_sign_in: ^6.2.1

dev_dependencies:
  flutter_test:
    sdk: flutter
  flutter_lints: ^3.0.0

flutter:
  uses-material-design: true
`
  },

  "main": {
    path: "lib/main.dart",
    language: "dart",
    description: "Main application entry point initializing simulated states and assembling multi-screen Providers.",
    content: `import 'package:flutter/material.dart';
import 'package:provider/provider.dart';
import 'package:google_fonts/google_fonts.dart';

import 'providers/test_provider.dart';
import 'screens/auth_screen.dart';
import 'screens/dashboard_screen.dart';

void main() {
  // Safe UI architecture initiation
  WidgetsFlutterBinding.ensureInitialized();
  runApp(const MyApp());
}

class MyApp extends StatelessWidget {
  const MyApp({super.key});

  @override
  Widget build(BuildContext context) {
    return MultiProvider(
      providers: [
        ChangeNotifierProvider(create: (_) => TestProvider()),
      ],
      child: MaterialApp(
        title: 'Mock Test Pro',
        debugShowCheckedModeBanner: false,
        themeMode: ThemeMode.system, // Harmonious system light/dark settings
        theme: ThemeData(
          useMaterial3: true,
          colorScheme: ColorScheme.fromSeed(
            seedColor: const Color(0xFF6366F1), // Deep Indigo accent
            brightness: Brightness.light,
            background: const Color(0xFFF9FAFB), // Cool neutral light background
          ),
          textTheme: GoogleFonts.interTextTheme(ThemeData.light().textTheme),
        ),
        darkTheme: ThemeData(
          useMaterial3: true,
          colorScheme: ColorScheme.fromSeed(
            seedColor: const Color(0xFF818CF8), // Vibrant indigo for dark mode
            brightness: Brightness.dark,
            background: const Color(0xFF0F172A), // Slate neutral background
          ),
          textTheme: GoogleFonts.interTextTheme(ThemeData.dark().textTheme),
        ),
        home: const AppRootSelector(),
      ),
    );
  }
}

/// Dynamic root router driven by secure state streams
class AppRootSelector extends StatelessWidget {
  const AppRootSelector({super.key});

  @override
  Widget build(BuildContext context) {
    final testProvider = Provider.of<TestProvider>(context);
    
    // Checks authentication token to render appropriate screen
    if (testProvider.isAuthenticated) {
      return const DashboardScreen();
    } else {
      return const AuthScreen();
    }
  }
}
`
  },

  "models": {
    path: "lib/models/mock_test.dart",
    language: "dart",
    description: "Robust data-transfer models for single Mock MCQ tests and questions.",
    content: `class Question {
  final String id;
  final String questionText;
  final List<String> options;
  final int correctOptionIndex;
  final String explanation;

  const Question({
    required this.id,
    required this.questionText,
    required this.options,
    required this.correctOptionIndex,
    required this.explanation,
  });

  factory Question.fromJson(Map<String, dynamic> json) {
    return Question(
      id: json['id'] as String,
      questionText: json['questionText'] as String,
      options: List<String>.from(json['options']),
      correctOptionIndex: json['correctOptionIndex'] as int,
      explanation: json['explanation'] as String? ?? 'Explanation is correct.',
    );
  }

  Map<String, dynamic> toJson() => {
    'id': id,
    'questionText': questionText,
    'options': options,
    'correctOptionIndex': correctOptionIndex,
    'explanation': explanation,
  };
}

class MockTest {
  final String id;
  final String title;
  final String subject;
  final int durationMinutes;
  final String difficulty;
  final List<Question> questions;

  const MockTest({
    required this.id,
    required this.title,
    required this.subject,
    required this.durationMinutes,
    required this.difficulty,
    required this.questions,
  });

  factory MockTest.fromJson(Map<String, dynamic> json) {
    var rawQs = json['questions'] as List;
    List<Question> qList = rawQs.map((q) => Question.fromJson(q)).toList();
    
    return MockTest(
      id: json['id'] as String,
      title: json['title'] as String,
      subject: json['subject'] as String,
      durationMinutes: json['durationMinutes'] as int? ?? 10,
      difficulty: json['difficulty'] as String? ?? 'Medium',
      questions: qList,
    );
  }

  Map<String, dynamic> toJson() => {
    'id': id,
    'title': title,
    'subject': subject,
    'durationMinutes': durationMinutes,
    'difficulty': difficulty,
    'questions': questions.map((q) => q.toJson()).toList(),
  };
}
`
  },

  "provider": {
    path: "lib/providers/test_provider.dart",
    language: "dart",
    description: "Multi-state controller holding users, tests list, timer values, results scoring, and error-handling routines.",
    content: `import 'dart:async';
import 'package:flutter/material.dart';
import '../models/mock_test.dart';

class TestProvider with ChangeNotifier {
  // Authentication properties
  bool _isAuthenticated = false;
  String? _userName;
  String? _userEmail;
  String? _userPhotoUrl;

  bool get isAuthenticated => _isAuthenticated;
  String? get userName => _userName;
  String? get userEmail => _userEmail;
  String? get userPhotoUrl => _userPhotoUrl;

  // Active Tests list
  final List<MockTest> _availableTests = [
    MockTest(
      id: 'flutter_basic',
      title: 'Flutter Fundamentals',
      subject: 'Mobile Development',
      durationMinutes: 5,
      difficulty: 'Easy',
      questions: [
        Question(
          id: 'fb1',
          questionText: 'Flutter में Widgets को डिफ़ॉल्ट रूप से बदलने के लिए किस स्टेट का उपयोग करते हैं?',
          options: [
            'StatefulWidget की State का',
            'InheritedWidget कांस्ट्रक्टर का',
            'StatelessWidget वैरिएबल का',
            'Static ग्लोबल प्रॉपर्टीज़ का'
          ],
          correctOptionIndex: 0,
          explanation: 'StatefulWidget की State में setState() को कॉल करके विगेट्स की रेंडरिंग को अपडेट और दोबारा ड्रा किया जाता है।'
        ),
        Question(
          id: 'fb2',
          questionText: 'Flutter SDK किस प्रोग्रामिंग भाषा का उपयोग करके मोबाइल ऐप्स बनाता है?',
          options: ['Java', 'Dart', 'Kotlin', 'Swift'],
          correctOptionIndex: 1,
          explanation: 'Flutter पूरी तरह से Dart प्रोग्रामिंग लैंग्वेज पर बना हुआ है, जो क्लाइंट-ऑप्टिमाइज्ड और सुपरफास्ट एग्जीक्यूशन प्रदान करता है।'
        ),
        Question(
          id: 'fb3',
          questionText: 'किस Widget का उपयोग चाइल्ड विजेट्स को स्क्रोल करने योग्य बनाने के लिए सबसे अधिक होता है?',
          options: ['SingleChildScrollView', 'Column', 'Container', 'Stack'],
          correctOptionIndex: 0,
          explanation: 'SingleChildScrollView का उपयोग सिंगल कॉलम या लंबे विजेट ट्री को स्क्रीन साइज़ के भीतर स्वाइप / स्क्रॉल करने की अनुमति देने के लिए करते हैं।'
        )
      ]
    ),
    MockTest(
      id: 'computer_networks',
      title: 'Computer Networks MCQ',
      subject: 'Information Technology',
      durationMinutes: 10,
      difficulty: 'Medium',
      questions: [
        Question(
          id: 'cn1',
          questionText: 'OSI मॉडल (OSI Reference Model) में कितनी परतें (Layers) होती हैं?',
          options: ['5 Layers', '6 Layers', '7 Layers', '8 Layers'],
          correctOptionIndex: 2,
          explanation: 'OSI मॉडल में कुल 7 परतें होती हैं: Physical, Data Link, Network, Transport, Session, Presentation, और Application।'
        ),
        Question(
          id: 'cn2',
          questionText: 'Web Browsing के दौरान http और https आर्किटेक्चर किस लेयर पर कार्य करता है?',
          options: ['Physical Layer', 'Transport Layer', 'Application Layer', 'Network Layer'],
          correctOptionIndex: 2,
          explanation: 'HTTP, HTTPS, और FTP जैसे प्रोटोकॉल पूरी तरह से एप्लीकेशन लेयर (Application Layer) पर काम करते हैं।'
        ),
        Question(
          id: 'cn3',
          questionText: 'IPv4 पते (IP Address) का आकार कितने बिट्स (Bits) का होता है?',
          options: ['16 bits', '32 bits', '64 bits', '128 bits'],
          correctOptionIndex: 1,
          explanation: 'IPv4 एड्रेस 32 बिट्स आकार का होता है जबकि IPv6 एड्रेस 128 बिट्स का होता है।'
        ),
        Question(
          id: 'cn4',
          questionText: 'DNS का पूर्ण रूप (Full Form) क्या होता है?',
          options: [
            'Directory Name System',
            'Domain Name System',
            'Dynamic Network Service',
            'Data Node Security'
          ],
          correctOptionIndex: 1,
          explanation: 'DNS का मतलब Domain Name System होता है जो मानव-पठनीय डोमेन नेम को आईपी एड्रेस में बदलता है।'
        )
      ]
    ),
  ];

  List<MockTest> get availableTests => _availableTests;

  // Active testing session properties
  MockTest? _activeTest;
  int _currentQuestionIndex = 0;
  final Map<int, int> _userAnswers = {}; // map of {questionIndex : optionSelected}
  
  // Timer attributes
  Timer? _countdownTimer;
  int _timeRemainingSeconds = 0;
  bool _isAutoSubmitted = false;

  MockTest? get activeTest => _activeTest;
  int get currentQuestionIndex => _currentQuestionIndex;
  Map<int, int> get userAnswers => _userAnswers;
  int get timeRemainingSeconds => _timeRemainingSeconds;
  bool get isAutoSubmitted => _isAutoSubmitted;

  // Final analytics scores
  Map<String, dynamic>? _testReport;
  Map<String, dynamic>? get testReport => _testReport;

  // Google Authentication Trigger
  Future<void> signInWithGoogle() async {
    try {
      // Simulate OAuth connection latency
      await Future.delayed(const Duration(milliseconds: 1200));

      _isAuthenticated = true;
      _userName = "Raman Kumar"; // Retrieved dynamically from UserCredential
      _userEmail = "raman.developer@gmail.com";
      _userPhotoUrl = "https://images.unsplash.com/photo-1534528741775-53994a69daeb?w=120"; // standard Google placeholder
      
      notifyListeners();
    } catch (e) {
      rethrow;
    }
  }

  // Authentication Sign Out
  Future<void> signOut() async {
    _isAuthenticated = false;
    _userName = null;
    _userEmail = null;
    _userPhotoUrl = null;
    resetActiveTest();
    notifyListeners();
  }

  // Active test control
  void startTest(MockTest test) {
    _activeTest = test;
    _currentQuestionIndex = 0;
    _userAnswers.clear();
    _isAutoSubmitted = false;
    _testReport = null;
    _timeRemainingSeconds = test.durationMinutes * 60;
    
    _startTimer();
    notifyListeners();
  }

  void _startTimer() {
    _countdownTimer?.cancel();
    _countdownTimer = Timer.periodic(const Duration(seconds: 1), (timer) {
      if (_timeRemainingSeconds > 0) {
        _timeRemainingSeconds--;
        notifyListeners();
      } else {
        _isAutoSubmitted = true;
        _countdownTimer?.cancel();
        submitTest();
      }
    });
  }

  void selectAnswer(int questionIndex, int optionIndex) {
    _userAnswers[questionIndex] = optionIndex;
    notifyListeners();
  }

  void navigateToQuestion(int index) {
    if (index >= 0 && index < (_activeTest?.questions.length ?? 0)) {
      _currentQuestionIndex = index;
      notifyListeners();
    }
  }

  // Compile final Report Card
  void submitTest() {
    _countdownTimer?.cancel();
    if (_activeTest == null) return;

    final questions = _activeTest!.questions;
    int correctCount = 0;
    int incorrectCount = 0;
    int unattemptedCount = 0;

    for (int i = 0; i < questions.length; i++) {
      if (!_userAnswers.containsKey(i)) {
        unattemptedCount++;
      } else if (_userAnswers[i] == questions[i].correctOptionIndex) {
        correctCount++;
      } else {
        incorrectCount++;
      }
    }

    double percentage = (correctCount / questions.length) * 100;

    _testReport = {
      'testTitle': _activeTest!.title,
      'subject': _activeTest!.subject,
      'totalQuestions': questions.length,
      'correct': correctCount,
      'incorrect': incorrectCount,
      'unattempted': unattemptedCount,
      'percentage': percentage.toStringAsFixed(1),
      'scoreAchieved': correctCount,
      'isPassed': percentage >= 40.0, // 40% criteria
    };

    notifyListeners();
  }

  void resetActiveTest() {
    _countdownTimer?.cancel();
    _activeTest = null;
    _currentQuestionIndex = 0;
    _userAnswers.clear();
    _testReport = null;
    notifyListeners();
  }

  // Developer Tool: Add fully custom mock test programmatically
  void addCustomMockTest(MockTest newTest) {
    // Add dynamically to provider's scope
    _availableTests.insert(0, newTest);
    notifyListeners();
  }

  @override
  void dispose() {
    _countdownTimer?.cancel();
    super.dispose();
  }
}
`
  },

  "auth_screen": {
    path: "lib/screens/auth_screen.dart",
    language: "dart",
    description: "A premium material 3 Google auth trigger with error handling, custom layouts, and a clean logo.",
    content: `import 'package:flutter/material.dart';
import 'package:provider/provider.dart';
import '../providers/test_provider.dart';

class AuthScreen extends StatefulWidget {
  const AuthScreen({super.key});

  @override
  State<AuthScreen> createState() => _AuthScreenState();
}

class _AuthScreenState extends State<AuthScreen> {
  bool _isLoading = false;

  Future<void> _handleGoogleSignIn() async {
    setState(() {
      _isLoading = true;
    });

    try {
      final testProvider = Provider.of<TestProvider>(context, listen: false);
      await testProvider.signInWithGoogle();

      if (mounted) {
        ScaffoldMessenger.of(context).showSnackBar(
          const SnackBar(
            content: Text("सफलतापूर्वक लॉगिन किया गया!"),
            backgroundColor: Colors.green,
            behavior: SnackBarBehavior.floating,
          ),
        );
      }
    } catch (error) {
      if (mounted) {
        ScaffoldMessenger.of(context).showSnackBar(
          SnackBar(
            content: Text("लॉगिन असफल: " + error.toString()),
            backgroundColor: Colors.red,
            behavior: SnackBarBehavior.floating,
          ),
        );
      }
    } finally {
      if (mounted) {
        setState(() {
          _isLoading = false;
        });
      }
    }
  }

  @override
  Widget build(BuildContext context) {
    final theme = Theme.of(context);
    final isDark = theme.brightness == Brightness.dark;

    return Scaffold(
      backgroundColor: theme.colorScheme.background,
      body: Center(
        child: SingleChildScrollView(
          padding: const EdgeInsets.symmetric(horizontal: 28.0),
          child: Column(
            mainAxisAlignment: MainAxisAlignment.center,
            crossAxisAlignment: CrossAxisAlignment.center,
            children: [
              // Beautiful vector logo sphere
              Container(
                height: 110,
                width: 110,
                decoration: BoxDecoration(
                  gradient: const LinearGradient(
                    colors: [Color(0xFF6366F1), Color(0xFF4F46E5)],
                    begin: Alignment.topLeft,
                    end: Alignment.bottomRight,
                  ),
                  borderRadius: BorderRadius.circular(30),
                  boxShadow: [
                    BoxShadow(
                      color: const Color(0xFF6366F1).withOpacity(0.3),
                      blurRadius: 20,
                      offset: const Offset(0, 10),
                    ),
                  ],
                ),
                child: const Icon(
                  Icons.quiz_rounded,
                  size: 56,
                  color: Colors.white,
                ),
              ),
              const SizedBox(height: 32),
              
              // App Headings
              Text(
                "Mock Test Pro",
                style: theme.textTheme.headlineMedium?.copyWith(
                  fontWeight: FontWeight.bold,
                  letterSpacing: -0.5,
                  fontSize: 32,
                  color: isDark ? Colors.white : const Color(0xFF1E293B),
                ),
              ),
              const SizedBox(height: 6),
              Text(
                "परीक्षा की तैयारी, अब हुई और भी आसान!",
                textAlign: TextAlign.center,
                style: theme.textTheme.bodyMedium?.copyWith(
                  color: isDark ? Colors.grey[400] : const Color(0xFF64748B),
                  fontSize: 16,
                ),
              ),
              const SizedBox(height: 48),

              // Sign in with Google card
              Container(
                width: double.infinity,
                padding: const EdgeInsets.all(24),
                decoration: BoxDecoration(
                  color: isDark ? const Color(0xFF1E293B) : Colors.white,
                  borderRadius: BorderRadius.circular(24),
                  border: Border.all(
                    color: isDark ? Colors.grey[800]! : Colors.grey[200]!,
                    width: 1,
                  ),
                  boxShadow: [
                    BoxShadow(
                      color: Colors.black.withOpacity(0.03),
                      blurRadius: 15,
                      offset: const Offset(0, 8),
                    )
                  ]
                ),
                child: Column(
                  children: [
                    Text(
                      "ऑथेंटिकेशन (Authentication)",
                      style: theme.textTheme.titleMedium?.copyWith(
                        fontWeight: FontWeight.w600,
                        fontSize: 18,
                      ),
                    ),
                    const SizedBox(height: 8),
                    Text(
                      "अपना स्कोर सुरक्षित करने और टेस्ट शुरू करने के लिए लॉगिन करें।",
                      textAlign: TextAlign.center,
                      style: theme.textTheme.bodySmall?.copyWith(
                        color: Colors.grey[500],
                        height: 1.4,
                      ),
                    ),
                    const SizedBox(height: 28),

                    // Elegant Google login button
                    SizedBox(
                      width: double.infinity,
                      height: 56,
                      child: ElevatedButton(
                        onPressed: _isLoading ? null : _handleGoogleSignIn,
                        style: ElevatedButton.styleFrom(
                          backgroundColor: isDark ? const Color(0xFF0F172A) : Colors.white,
                          surfaceTintColor: Colors.transparent,
                          foregroundColor: isDark ? Colors.white : const Color(0xFF334155),
                          elevation: 0,
                          side: Border.all(
                            color: isDark ? Colors.grey[700]! : const Color(0xFFCBD5E1),
                            width: 1.5,
                          ),
                          shape: RoundedRectangleBorder(
                            borderRadius: BorderRadius.circular(16),
                          ),
                        ),
                        child: _isLoading
                            ? const SizedBox(
                                height: 24,
                                width: 24,
                                child: CircularProgressIndicator(strokeWidth: 2.5),
                              )
                            : Row(
                                mainAxisAlignment: MainAxisAlignment.center,
                                children: [
                                  // Simplified clean Vector-styled G icon
                                  Image.network(
                                    'https://upload.wikimedia.org/wikipedia/commons/c/c1/Google_%22G%22_logo.svg',
                                    height: 22,
                                    width: 22,
                                    errorBuilder: (context, error, stackTrace) {
                                      return const Icon(Icons.g_mobiledata_rounded, size: 24);
                                    },
                                  ),
                                  const SizedBox(width: 14),
                                  const Text(
                                    "Google से लॉगिन करें",
                                    style: TextStyle(
                                      fontWeight: FontWeight.bold,
                                      fontSize: 16,
                                    ),
                                  ),
                                ],
                              ),
                      ),
                    ),
                  ],
                ),
              ),
              const SizedBox(height: 40),
              
              // Bottom Footer Text
              Text(
                "डेटा सुरक्षा मानदंड: Firebase Auth और Google Sign-In द्वारा सुरक्षित।",
                style: TextStyle(
                  color: Colors.grey[600],
                  fontSize: 11,
                ),
                textAlign: TextAlign.center,
              )
            ],
          ),
        ),
      ),
    );
  }
}
`
  },

  "dashboard_screen": {
    path: "lib/screens/dashboard_screen.dart",
    language: "dart",
    description: "Home Dashboard listing user stats, available tests dynamically, and facilitating seamless quiz transitions.",
    content: `import 'package:flutter/material.dart';
import 'package:provider/provider.dart';
import '../providers/test_provider.dart';
import 'quiz_screen.dart';

class DashboardScreen extends StatelessWidget {
  const DashboardScreen({super.key});

  @override
  Widget build(BuildContext context) {
    final provider = Provider.of<TestProvider>(context);
    final theme = Theme.of(context);
    final isDark = theme.brightness == Brightness.dark;

    return Scaffold(
      backgroundColor: theme.colorScheme.background,
      appBar: AppBar(
        toolbarHeight: 80,
        backgroundColor: isDark ? const Color(0xFF0F172A) : Colors.white,
        elevation: 0,
        scrolledUnderElevation: 2.0,
        leadingWidth: 0,
        automaticallyImplyLeading: false,
        title: Row(
          children: [
            // Safe Google Profile picture with soft borders
            Container(
              margin: const EdgeInsets.only(right: 12),
              decoration: BoxDecoration(
                shape: BoxShape.circle,
                border: Border.all(
                  color: theme.colorScheme.primary.withOpacity(0.4),
                  width: 2,
                ),
              ),
              child: ClipOval(
                child: Image.network(
                  provider.userPhotoUrl ?? 'https://images.unsplash.com/photo-1534528741775-53994a69daeb?w=120',
                  height: 48,
                  width: 48,
                  fit: BoxFit.cover,
                  errorBuilder: (context, error, stackTrace) {
                    return const CircleAvatar(
                      radius: 24,
                      child: Icon(Icons.person),
                    );
                  },
                ),
              ),
            ),
            Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Text(
                  "राम राम, " + (provider.userName ?? "यूजर"),
                  style: theme.textTheme.titleMedium?.copyWith(
                    fontWeight: FontWeight.bold,
                    fontSize: 18,
                  ),
                ),
                Text(
                  provider.userEmail ?? "student@domain.com",
                  style: theme.textTheme.bodySmall?.copyWith(
                    color: Colors.grey[500],
                  ),
                )
              ],
            ),
          ],
        ),
        actions: [
          IconButton(
            onPressed: () => provider.signOut(),
            tooltip: "लॉगआउट",
            icon: const Icon(Icons.logout_rounded, color: Colors.redAccent),
          ),
          const SizedBox(width: 12),
        ],
      ),
      body: SingleChildScrollView(
        physics: const BouncingScrollPhysics(),
        padding: const EdgeInsets.all(20.0),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            // Welcome Card/Banners
            Container(
              width: double.infinity,
              padding: const EdgeInsets.all(24),
              decoration: BoxDecoration(
                gradient: const LinearGradient(
                  colors: [Color(0xFF6366F1), Color(0xFF818CF8)],
                  begin: Alignment.topLeft,
                  end: Alignment.bottomRight,
                ),
                borderRadius: BorderRadius.circular(24),
              ),
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Container(
                    padding: const EdgeInsets.symmetric(horizontal: 10, vertical: 4),
                    decoration: BoxDecoration(
                      color: Colors.white.withOpacity(0.2),
                      borderRadius: BorderRadius.circular(30),
                    ),
                    child: const Text(
                      "तैयारी मोड सक्रिय है",
                      style: TextStyle(
                        color: Colors.white,
                        fontSize: 11,
                        fontWeight: FontWeight.bold,
                      ),
                    ),
                  ),
                  const SizedBox(height: 14),
                  const Text(
                    "अपने ज्ञान का परीक्षण करें",
                    style: TextStyle(
                      color: Colors.white,
                      fontSize: 24,
                      fontWeight: FontWeight.bold,
                    ),
                  ),
                  const SizedBox(height: 6),
                  const Text(
                    "नीचे दिए गए किसी भी मॉक टेस्ट को चुनें और वास्तविक समय सीमा के भीतर हल करने का प्रयास करें।",
                    style: TextStyle(
                      color: Colors.white70,
                      fontSize: 13,
                      height: 1.4,
                    ),
                  ),
                ],
              ),
            ),
            const SizedBox(height: 24),

            // Heading of tests list
            Row(
              mainAxisAlignment: MainAxisAlignment.spaceBetween,
              children: [
                Text(
                  "उपलब्ध मॉक टेस्ट (\${provider.availableTests.length})",
                  style: theme.textTheme.titleMedium?.copyWith(
                    fontWeight: FontWeight.bold,
                    fontSize: 20,
                  ),
                ),
                const Icon(Icons.sort_rounded, color: Colors.grey)
              ],
            ),
            const SizedBox(height: 16),

            // Dynamic tests scrolling card list
            ListView.builder(
              shrinkWrap: true,
              physics: const NeverScrollableScrollPhysics(),
              itemCount: provider.availableTests.length,
              itemBuilder: (context, index) {
                final test = provider.availableTests[index];
                final qCount = test.questions.length;
                final minutes = test.durationMinutes;

                // Color based on difficulty to look beautiful
                Color difficultyColor = Colors.green;
                if (test.difficulty.toLowerCase() == 'medium') {
                  difficultyColor = Colors.orange;
                } else if (test.difficulty.toLowerCase() == 'hard') {
                  difficultyColor = Colors.red;
                }

                return Card(
                  margin: const EdgeInsets.only(bottom: 16),
                  elevation: 0,
                  color: isDark ? const Color(0xFF1E293B) : Colors.white,
                  shape: RoundedRectangleBorder(
                    borderRadius: BorderRadius.circular(20),
                    side: Border.all(
                      color: isDark ? Colors.grey[800]! : Colors.grey[200]!,
                      width: 1,
                    )
                  ),
                  child: Padding(
                    padding: const EdgeInsets.all(20.0),
                    child: Column(
                      crossAxisAlignment: CrossAxisAlignment.start,
                      children: [
                        Row(
                          mainAxisAlignment: MainAxisAlignment.spaceBetween,
                          children: [
                            Container(
                              padding: const EdgeInsets.symmetric(horizontal: 10, vertical: 4),
                              decoration: BoxDecoration(
                                color: difficultyColor.withOpacity(0.12),
                                borderRadius: BorderRadius.circular(12),
                              ),
                              child: Text(
                                test.difficulty,
                                style: TextStyle(
                                  color: difficultyColor,
                                  fontSize: 11,
                                  fontWeight: FontWeight.bold,
                                ),
                              ),
                            ),
                            Text(
                              test.subject,
                              style: TextStyle(
                                color: isDark ? Colors.indigo[300] : const Color(0xFF4F46E5),
                                fontWeight: FontWeight.w600,
                                fontSize: 13,
                              ),
                            ),
                          ],
                        ),
                        const SizedBox(height: 12),
                        Text(
                          test.title,
                          style: theme.textTheme.titleMedium?.copyWith(
                            fontWeight: FontWeight.bold,
                            fontSize: 18,
                          ),
                        ),
                        const SizedBox(height: 16),
                        Divider(color: Colors.grey[300]?.withOpacity(0.3), height: 1),
                        const SizedBox(height: 16),
                        Row(
                          mainAxisAlignment: MainAxisAlignment.spaceBetween,
                          children: [
                            Row(
                              children: [
                                Icon(Icons.help_outline_rounded, size: 18, color: Colors.grey[500]),
                                const SizedBox(width: 6),
                                Text(
                                  "$qCount प्रश्न",
                                  style: TextStyle(color: Colors.grey[600], fontSize: 13),
                                ),
                                const SizedBox(width: 16),
                                Icon(Icons.timer_outlined, size: 18, color: Colors.grey[500]),
                                const SizedBox(width: 6),
                                Text(
                                  "$minutes मिनट",
                                  style: TextStyle(color: Colors.grey[600], fontSize: 13),
                                ),
                              ],
                            ),
                            
                            ElevatedButton(
                              onPressed: () {
                                provider.startTest(test);
                                Navigator.push(
                                  context,
                                  MaterialPageRoute(builder: (_) => const QuizScreen()),
                                );
                              },
                              style: ElevatedButton.styleFrom(
                                backgroundColor: const Color(0xFF6366F1),
                                foregroundColor: Colors.white,
                                elevation: 0,
                                padding: const EdgeInsets.symmetric(horizontal: 18, vertical: 12),
                                shape: RoundedRectangleBorder(
                                  borderRadius: BorderRadius.circular(12),
                                ),
                              ),
                              child: const Row(
                                mainAxisSize: MainAxisSize.min,
                                children: [
                                  Text(
                                    "शुरू करें",
                                    style: TextStyle(fontWeight: FontWeight.bold),
                                  ),
                                  SizedBox(width: 6),
                                  Icon(Icons.arrow_forward_rounded, size: 16),
                                ],
                              ),
                            ),
                          ],
                        ),
                      ],
                    ),
                  ),
                );
              },
            ),
          ],
        ),
      ),
    );
  }
}
`
  },

  "quiz_screen": {
    path: "lib/screens/quiz_screen.dart",
    language: "dart",
    description: "The core Exam component featuring live countdown timer auto-submitting state, radio outlines, and rich tracking widgets.",
    content: `import 'package:flutter/material.dart';
import 'package:provider/provider.dart';
import '../providers/test_provider.dart';
import 'result_screen.dart';

class QuizScreen extends StatefulWidget {
  const QuizScreen({super.key});

  @override
  State<QuizScreen> createState() => _QuizScreenState();
}

class _QuizScreenState extends State<QuizScreen> {
  
  String _formatTimer(int totalSeconds) {
    int minutes = totalSeconds ~/ 60;
    int seconds = totalSeconds % 60;
    String minStr = minutes.toString().padLeft(2, '0');
    String secStr = seconds.toString().padLeft(2, '0');
    return "$minStr:$secStr";
  }

  void _showSubmitConfirmation(BuildContext context, TestProvider provider) {
    showDialog(
      context: context,
      builder: (BuildContext ctx) {
        return AlertDialog(
          shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(20)),
          title: const Text("टेस्ट सबमिट करें?"),
          content: Text("क्या आप सच में इस टेस्ट को समाप्त करके परिणाम देखना चाहते हैं? आपने \${provider.userAnswers.length} में से \${provider.activeTest?.questions.length} प्रश्नों के उत्तर दिए हैं।"),
          actions: [
            TextButton(
              onPressed: () => Navigator.pop(ctx),
              child: const Text("रद्द करें", style: TextStyle(color: Colors.grey)),
            ),
            ElevatedButton(
              onPressed: () {
                Navigator.pop(ctx); // pop dialog
                provider.submitTest();
                Navigator.pushReplacement(
                  context,
                  MaterialPageRoute(builder: (_) => const ResultScreen()),
                );
              },
              style: ElevatedButton.styleFrom(backgroundColor: Colors.indigo),
              child: const Text("हाँ, सबमिट करें", style: TextStyle(color: Colors.white)),
            ),
          ],
        );
      },
    );
  }

  @override
  Widget build(BuildContext context) {
    final provider = Provider.of<TestProvider>(context);
    final theme = Theme.of(context);
    final isDark = theme.brightness == Brightness.dark;

    final activeTest = provider.activeTest;
    if (activeTest == null) {
      return const Scaffold(
        body: Center(child: Text("कोई सक्रिय परीक्षा सत्र नहीं मिला।")),
      );
    }

    final currentIdx = provider.currentQuestionIndex;
    final question = activeTest.questions[currentIdx];
    final totalQs = activeTest.questions.length;
    
    // Percentage metrics for Linear Progress Bar
    double progressPercent = (currentIdx + 1) / totalQs;

    // Check if time warning is active (less than 30 seconds left)
    bool isUrgentTime = provider.timeRemainingSeconds <= 30;

    return WillPopScope(
      onWillPop: () async {
        // Safe alert preventing accidental exits
        bool shouldExit = false;
        await showDialog(
          context: context,
          builder: (context) => AlertDialog(
            shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(20)),
            title: const Text("परीक्षा छोड़ें?"),
            content: const Text("बीच में परीक्षा छोड़ने से आपका कोई स्कोर दर्ज नहीं होगा।"),
            actions: [
              TextButton(
                onPressed: () => Navigator.pop(context),
                child: const Text("वापस जाएँ (Stay)"),
              ),
              TextButton(
                onPressed: () {
                  shouldExit = true;
                  Navigator.pop(context);
                },
                child: const Text("छोड़ें (Quit)", style: TextStyle(color: Colors.red)),
              )
            ],
          )
        );
        if (shouldExit) {
          provider.resetActiveTest();
        }
        return shouldExit;
      },
      child: Scaffold(
        backgroundColor: theme.colorScheme.background,
        appBar: AppBar(
          backgroundColor: isDark ? const Color(0xFF0F172A) : Colors.white,
          elevation: 0,
          leading: IconButton(
            icon: const Icon(Icons.close_rounded),
            onPressed: () {
              Navigator.maybePop(context);
            },
          ),
          title: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              Text(
                activeTest.title,
                style: const TextStyle(fontSize: 16, fontWeight: FontWeight.bold),
              ),
              Text(
                "विषय: " + activeTest.subject,
                style: const TextStyle(fontSize: 12, color: Colors.grey),
              ),
            ],
          ),
          actions: [
            // Safe beautiful countdown widget
            Container(
              margin: const EdgeInsets.only(right: 16),
              padding: const EdgeInsets.symmetric(horizontal: 14, vertical: 8),
              decoration: BoxDecoration(
                color: isUrgentTime 
                    ? Colors.redAccent.withOpacity(0.1) 
                    : theme.colorScheme.primary.withOpacity(0.08),
                borderRadius: BorderRadius.circular(12),
                border: Border.all(
                  color: isUrgentTime ? Colors.redAccent : theme.colorScheme.primary,
                  width: 1,
                ),
              ),
              child: Row(
                children: [
                  Icon(
                    Icons.timer, 
                    size: 16, 
                    color: isUrgentTime ? Colors.redAccent : theme.colorScheme.primary
                  ),
                  const SizedBox(width: 6),
                  Text(
                    _formatTimer(provider.timeRemainingSeconds),
                    style: TextStyle(
                      fontWeight: FontWeight.bold,
                      fontSize: 14,
                      color: isUrgentTime ? Colors.redAccent : theme.colorScheme.primary,
                    ),
                  ),
                ],
              ),
            ),
          ],
        ),
        body: Column(
          children: [
            // Linear Progress indicators showing tracking index
            LinearProgressIndicator(
              value: progressPercent,
              minHeight: 5,
              backgroundColor: isDark ? Colors.grey[800] : Colors.grey[200],
              valueColor: const AlwaysStoppedAnimation<Color>(Color(0xFF6366F1)),
            ),
            
            // Core Interactive Question Zone
            Expanded(
              child: SingleChildScrollView(
                padding: const EdgeInsets.all(24.0),
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    // Index badge
                    Row(
                      mainAxisAlignment: MainAxisAlignment.spaceBetween,
                      children: [
                        Container(
                          padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 6),
                          decoration: BoxDecoration(
                            color: const Color(0xFF6366F1).withOpacity(0.1),
                            borderRadius: BorderRadius.circular(10),
                          ),
                          child: Text(
                            "प्रश्न: \${currentIdx + 1} / \$totalQs",
                            style: const TextStyle(
                              color: Color(0xFF6366F1),
                              fontWeight: FontWeight.bold,
                              fontSize: 13,
                            ),
                          ),
                        ),
                        Text(
                          provider.userAnswers.containsKey(currentIdx) ? "उत्तर दिया" : "लंबित",
                          style: TextStyle(
                            color: provider.userAnswers.containsKey(currentIdx) ? Colors.green : Colors.grey[500],
                            fontSize: 12,
                            fontWeight: FontWeight.w600,
                          ),
                        ),
                      ],
                    ),
                    const SizedBox(height: 20),

                    // Question Bold Label
                    Text(
                      question.questionText,
                      style: theme.textTheme.headlineSmall?.copyWith(
                        fontWeight: FontWeight.bold,
                        height: 1.4,
                        fontSize: 20,
                        color: isDark ? Colors.white : const Color(0xFF1E293B),
                      ),
                    ),
                    const SizedBox(height: 32),

                    // Options Container Selection logic
                    ListView.builder(
                      shrinkWrap: true,
                      physics: const NeverScrollableScrollPhysics(),
                      itemCount: question.options.length,
                      itemBuilder: (context, optIdx) {
                        final optionText = question.options[optIdx];
                        final isSelected = provider.userAnswers[currentIdx] == optIdx;

                        return Container(
                          margin: const EdgeInsets.only(bottom: 16),
                          child: InkWell(
                            onTap: () {
                              provider.selectAnswer(currentIdx, optIdx);
                            },
                            borderRadius: BorderRadius.circular(16),
                            child: AnimatedContainer(
                              duration: const Duration(milliseconds: 150),
                              padding: const EdgeInsets.symmetric(horizontal: 20, vertical: 16),
                              decoration: BoxDecoration(
                                color: isSelected 
                                    ? const Color(0xFF6366F1).withOpacity(0.08) 
                                    : (isDark ? const Color(0xFF192138) : Colors.white),
                                borderRadius: BorderRadius.circular(16),
                                border: Border.all(
                                  color: isSelected 
                                      ? const Color(0xFF6366F1) 
                                      : (isDark ? Colors.grey[800]! : Colors.grey[300]!),
                                  width: isSelected ? 2 : 1.2,
                                ),
                              ),
                              child: Row(
                                children: [
                                  // Elegant state circles
                                  Container(
                                    height: 22,
                                    width: 22,
                                    decoration: BoxDecoration(
                                      shape: BoxShape.circle,
                                      border: Border.all(
                                        color: isSelected ? const Color(0xFF6366F1) : Colors.grey[400]!,
                                        width: isSelected ? 6 : 1.5,
                                      ),
                                    ),
                                  ),
                                  const SizedBox(width: 14),
                                  Expanded(
                                    child: Text(
                                      optionText,
                                      style: theme.textTheme.bodyMedium?.copyWith(
                                        fontWeight: isSelected ? FontWeight.w600 : FontWeight.normal,
                                        fontSize: 15,
                                      ),
                                    ),
                                  ),
                                ],
                              ),
                            ),
                          ),
                        );
                      },
                    ),
                  ],
                ),
              ),
            ),
            
            // Bottom Action Navigation Deck
            Container(
              padding: const EdgeInsets.symmetric(horizontal: 24, vertical: 18),
              decoration: BoxDecoration(
                color: isDark ? const Color(0xFF0F172A) : Colors.white,
                boxShadow: [
                  BoxShadow(
                    color: Colors.black.withOpacity(0.04),
                    blurRadius: 10,
                    offset: const Offset(0, -5),
                  )
                ]
              ),
              child: Row(
                mainAxisAlignment: MainAxisAlignment.spaceBetween,
                children: [
                  // Previous button
                  ElevatedButton(
                    onPressed: currentIdx > 0 
                        ? () => provider.navigateToQuestion(currentIdx - 1) 
                        : null,
                    style: ElevatedButton.styleFrom(
                      backgroundColor: isDark ? Colors.grey[800] : Colors.grey[100],
                      foregroundColor: isDark ? Colors.white : Colors.black87,
                      disabledBackgroundColor: isDark ? Colors.grey[900]?.withOpacity(0.4) : Colors.grey[100]?.withOpacity(0.4),
                      elevation: 0,
                      shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(12)),
                      padding: const EdgeInsets.symmetric(horizontal: 18, vertical: 14),
                    ),
                    child: const Row(
                      children: [
                        Icon(Icons.arrow_back_rounded, size: 16),
                        SizedBox(width: 6),
                        Text("पीछे", style: TextStyle(fontWeight: FontWeight.bold)),
                      ],
                    ),
                  ),

                  // Next or Submit Test Button
                  ElevatedButton(
                    onPressed: () {
                      if (currentIdx < totalQs - 1) {
                        provider.navigateToQuestion(currentIdx + 1);
                      } else {
                        _showSubmitConfirmation(context, provider);
                      }
                    },
                    style: ElevatedButton.styleFrom(
                      backgroundColor: currentIdx < totalQs - 1 
                          ? const Color(0xFF6366F1) 
                          : Colors.green,
                      foregroundColor: Colors.white,
                      elevation: 0,
                      shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(12)),
                      padding: const EdgeInsets.symmetric(horizontal: 22, vertical: 14),
                    ),
                    child: Row(
                      children: [
                        Text(
                          currentIdx < totalQs - 1 ? "अगला" : "सबमिट टेस्ट",
                          style: const TextStyle(fontWeight: FontWeight.bold),
                        ),
                        const SizedBox(width: 6),
                        Icon(
                          currentIdx < totalQs - 1 ? Icons.arrow_forward_rounded : Icons.check_circle_outline, 
                          size: 16
                        ),
                      ],
                    ),
                  ),
                ],
              ),
            ),
          ],
        ),
      ),
    );
  }
}
`
  },

  "result_screen": {
    path: "lib/screens/result_screen.dart",
    language: "dart",
    description: "The complete analytics dashboard showing calculated grades, answers status list, explanations, and CTA triggers. Includes Hindi translation.",
    content: `import 'package:flutter/material.dart';
import 'package:provider/provider.dart';
import '../providers/test_provider.dart';

class ResultScreen extends StatelessWidget {
  const ResultScreen({super.key});

  @override
  Widget build(BuildContext context) {
    final provider = Provider.of<TestProvider>(context);
    final theme = Theme.of(context);
    final isDark = theme.brightness == Brightness.dark;

    final report = provider.testReport;
    final activeTest = provider.activeTest;

    if (report == null || activeTest == null) {
      return const Scaffold(
        body: Center(child: Text("स्पष्ट स्कोर कार्ड रिपोर्ट लोड करने में असमर्थ।")),
      );
    }

    final isPassed = report['isPassed'] as bool;
    final totalQs = report['totalQuestions'] as int;
    final correct = report['correct'] as int;
    final incorrect = report['incorrect'] as int;
    final unattempted = report['unattempted'] as int;
    final percentage = report['percentage'] as String;

    return Scaffold(
      backgroundColor: theme.colorScheme.background,
      body: SafeArea(
        child: SingleChildScrollView(
          physics: const BouncingScrollPhysics(),
          padding: const EdgeInsets.all(24.0),
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.center,
            children: [
              const SizedBox(height: 16),
              
              // Animated Trophy container
              Container(
                height: 110,
                width: 110,
                decoration: BoxDecoration(
                  color: isPassed 
                      ? Colors.amber.withOpacity(0.12) 
                      : Colors.redAccent.withOpacity(0.12),
                  shape: BoxShape.circle,
                ),
                child: Center(
                  child: Icon(
                    isPassed ? Icons.emoji_events_rounded : Icons.campaign_rounded,
                    size: 60,
                    color: isPassed ? Colors.amber[700] : Colors.redAccent,
                  ),
                ),
              ),
              const SizedBox(height: 24),

              Text(
                isPassed ? "बधाई हो! (Congratulations)" : "और प्रयास करें! (Try Harder)",
                style: theme.textTheme.headlineSmall?.copyWith(
                  fontWeight: FontWeight.bold,
                  color: isPassed ? Colors.green : Colors.orange,
                ),
              ),
              const SizedBox(height: 6),
              Text(
                isPassed ? "आपने सफलतापूर्वक मॉक टेस्ट उत्तीर्ण कर लिया है।" : "कोई बात नहीं! आप अगली बार बेहतर कर सकते हैं।",
                textAlign: TextAlign.center,
                style: TextStyle(color: Colors.grey[500], fontSize: 13),
              ),
              const SizedBox(height: 32),

              // Comprehensive score summary card with grid layout
              Container(
                width: double.infinity,
                padding: const EdgeInsets.all(24),
                decoration: BoxDecoration(
                  color: isDark ? const Color(0xFF1E293B) : Colors.white,
                  borderRadius: BorderRadius.circular(24),
                  border: Border.all(
                    color: isDark ? Colors.grey[800]! : Colors.grey[200]!,
                    width: 1,
                  ),
                ),
                child: Column(
                  children: [
                    Text(
                      "$percentage%",
                      style: TextStyle(
                        fontSize: 48,
                        fontWeight: FontWeight.w900,
                        color: isDark ? Colors.indigo[300] : const Color(0xFF4F46E5),
                      ),
                    ),
                    Text(
                      "कुल अंक (Total Score Percentage)",
                      style: TextStyle(
                        color: Colors.grey[500],
                        fontSize: 12,
                        fontWeight: FontWeight.w500,
                      ),
                    ),
                    const SizedBox(height: 24),
                    Divider(color: Colors.grey[300]?.withOpacity(0.3), height: 1),
                    const SizedBox(height: 24),

                    // Grid metric rows
                    Row(
                      mainAxisAlignment: MainAxisAlignment.spaceAround,
                      children: [
                        _buildMetricCol("सही उत्तर", "$correct", Colors.green, theme),
                        _buildMetricCol("गलत उत्तर", "$incorrect", Colors.redAccent, theme),
                        _buildMetricCol("छोड़े गए", "$unattempted", Colors.grey, theme),
                      ],
                    ),
                  ],
                ),
              ),
              const SizedBox(height: 32),

              // Detailed Analysis with explanations
              Align(
                alignment: Alignment.centerLeft,
                child: Text(
                  "उत्तर विश्लेषण और स्पष्टीकरण (Explanations)",
                  style: theme.textTheme.titleMedium?.copyWith(
                    fontWeight: FontWeight.bold,
                    fontSize: 18,
                  ),
                ),
              ),
              const SizedBox(height: 16),

              // Explanations loop
              ListView.builder(
                shrinkWrap: true,
                physics: const NeverScrollableScrollPhysics(),
                itemCount: totalQs,
                itemBuilder: (context, idx) {
                  final question = activeTest.questions[idx];
                  final isAnswered = provider.userAnswers.containsKey(idx);
                  final selectedOpt = provider.userAnswers[idx];
                  final isCorrect = selectedOpt == question.correctOptionIndex;

                  return Card(
                    margin: const EdgeInsets.only(bottom: 16),
                    elevation: 0,
                    color: isDark ? const Color(0xFF151D30) : Colors.white,
                    shape: RoundedRectangleBorder(
                      borderRadius: BorderRadius.circular(16),
                      side: Border.all(
                        color: isAnswered 
                            ? (isCorrect ? Colors.green.withOpacity(0.3) : Colors.redAccent.withOpacity(0.3))
                            : Colors.grey[400]!.withOpacity(0.2),
                        width: 1,
                      )
                    ),
                    child: Padding(
                      padding: const EdgeInsets.all(18.0),
                      child: Column(
                        crossAxisAlignment: CrossAxisAlignment.start,
                        children: [
                          Row(
                            children: [
                              Icon(
                                isAnswered 
                                    ? (isCorrect ? Icons.check_circle_rounded : Icons.cancel_rounded)
                                    : Icons.remove_circle_rounded,
                                color: isAnswered ? (isCorrect ? Colors.green : Colors.redAccent) : Colors.grey,
                                size: 20,
                              ),
                              const SizedBox(width: 8),
                              Text(
                                "प्रश्न \${idx + 1}",
                                style: const TextStyle(fontWeight: FontWeight.bold, fontSize: 13),
                              ),
                            ],
                          ),
                          const SizedBox(height: 10),
                          Text(
                            question.questionText,
                            style: const TextStyle(fontWeight: FontWeight.w600, fontSize: 14),
                          ),
                          const SizedBox(height: 12),
                          
                          // Display select metric text
                          Text(
                            "आपका उत्तर: " + (isAnswered ? question.options[selectedOpt!] : "छोड़ दिया"),
                            style: TextStyle(
                              fontSize: 13, 
                              color: isCorrect ? Colors.green : Colors.redAccent,
                              fontWeight: FontWeight.w500,
                            ),
                          ),
                          if (!isCorrect) 
                            Text(
                              "सही उत्तर: " + question.options[question.correctOptionIndex],
                              style: const TextStyle(
                                fontSize: 13, 
                                color: Colors.green,
                                fontWeight: FontWeight.w500,
                              ),
                            ),
                          const SizedBox(height: 8),
                          
                          // Explanation
                          Container(
                            width: double.infinity,
                            padding: const EdgeInsets.all(12),
                            decoration: BoxDecoration(
                              color: isDark ? Colors.blueGrey[950]?.withOpacity(0.3) : Colors.grey[50],
                              borderRadius: BorderRadius.circular(8),
                            ),
                            child: Text(
                              "स्पष्टीकरण: " + question.explanation,
                              style: TextStyle(
                                fontSize: 12, 
                                color: isDark ? Colors.grey[400] : Colors.grey[700],
                                height: 1.4
                              ),
                            ),
                          ),
                        ],
                      ),
                    ),
                  );
                },
              ),
              const SizedBox(height: 24),

              // Bottom Actions
              Row(
                children: [
                  Expanded(
                    child: ElevatedButton.styleFrom(
                      elevation: 0,
                      shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(12)),
                      padding: const EdgeInsets.symmetric(vertical: 16),
                      backgroundColor: isDark ? Colors.grey[850] : Colors.grey[200],
                    ).button(
                      onPressed: () {
                        provider.resetActiveTest();
                        Navigator.of(context).popUntil((route) => route.isFirst);
                      },
                      child: Text(
                        "डैशबोर्ड पर जाएँ",
                        style: TextStyle(
                          color: isDark ? Colors.white : Colors.black87,
                          fontWeight: FontWeight.bold
                        ),
                      ),
                    ),
                  ),
                  const SizedBox(width: 16),
                  Expanded(
                    child: ElevatedButton(
                      onPressed: () {
                        provider.startTest(activeTest);
                        Navigator.pushReplacement(
                          context,
                          MaterialPageRoute(builder: (_) => const QuizScreen()),
                        );
                      },
                      style: ElevatedButton.styleFrom(
                        backgroundColor: const Color(0xFF6366F1),
                        foregroundColor: Colors.white,
                        elevation: 0,
                        shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(12)),
                        padding: const EdgeInsets.symmetric(vertical: 16),
                      ),
                      child: const Text(
                        "पुनः प्रयास करें",
                        style: TextStyle(fontWeight: FontWeight.bold),
                      ),
                    ),
                  ),
                ],
              ),
              const SizedBox(height: 48),
            ],
          ),
        ),
      ),
    );
  }

  Widget _buildMetricCol(String label, String value, Color color, ThemeData theme) {
    return Column(
      children: [
        Text(
          value,
          style: TextStyle(
            fontSize: 24,
            fontWeight: FontWeight.bold,
            color: color,
          ),
        ),
        const SizedBox(height: 4),
        Text(
          label,
          style: TextStyle(
            fontSize: 12,
            color: Colors.grey[500],
            fontWeight: FontWeight.w500,
          ),
        ),
      ],
    );
  }
}

// Extension to avoid compilation error for Button configuration styles
extension ElevatedButtonExtension on ElevatedButton {
  Widget button({required VoidCallback onPressed, required Widget child}) {
    return ElevatedButton(
      onPressed: onPressed,
      style: style,
      child: child,
    );
  }
}
`
  }
};
