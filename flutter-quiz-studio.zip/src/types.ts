/**
 * Shared Type Definitions for the Mock Test and Simulator Application
 */

export interface Question {
  id: string;
  questionText: string;
  options: string[]; // exactly 4 options
  correctOptionIndex: number; // 0, 1, 2, or 3
  explanation: string;
}

export interface MockTest {
  id: string;
  title: string;
  subject: string;
  durationMinutes: number;
  difficulty: "Easy" | "Medium" | "Hard";
  questions: Question[];
  createdBy?: string;
  createdAt?: string;
}

export interface MockUser {
  name: string;
  email: string;
  photoUrl: string;
  uid?: string;
}

export interface TestSession {
  test: MockTest;
  selectedAnswers: Record<number, number>; // index of question -> index of option
  status: 'not_started' | 'in_progress' | 'completed';
  timeRemainingSeconds: number;
  score: {
    correct: number;
    incorrect: number;
    unattempted: number;
    percentage: number;
  } | null;
}
