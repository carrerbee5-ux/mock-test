import express from "express";
import path from "path";
import dotenv from "dotenv";
import { createServer as createViteServer } from "vite";
import { GoogleGenAI, Type } from "@google/genai";

dotenv.config();

// Initialize express
const app = express();
app.use(express.json());

const PORT = 3000;

// Initialize Gemini Client
const apiKey = process.env.GEMINI_API_KEY;
let ai: GoogleGenAI | null = null;

if (apiKey) {
  ai = new GoogleGenAI({
    apiKey: apiKey,
    httpOptions: {
      headers: {
        'User-Agent': 'aistudio-build',
      }
    }
  });
} else {
  console.warn("WARNING: GEMINI_API_KEY is not defined in environment variables. Dynamic generation will work in mock mode.");
}

// 1. API Route: Dynamic Quiz/Mock Test Generation using Gemini
app.post("/api/generate-test", async (req, res): Promise<any> => {
  const { topic, difficulty, questionCount = 5 } = req.body;

  if (!topic) {
    return res.status(400).json({ error: "Please provide a valid topic name." });
  }

  // Fallback Mock data if Gemini key is missing
  if (!ai) {
    console.log("Using Mock generator fallback as GEMINI_API_KEY is missing.");
    return res.json({
      test: generateMockFallbackTest(topic, difficulty || "Medium", questionCount)
    });
  }

  try {
    const prompt = `Create a professional and premium mock test about "${topic}" with general difficulty level "${difficulty || "Medium"}".
Generate exactly ${questionCount} multiple-choice questions. It should be highly detailed, academic, and realistic. Provide clear outlines.
The responses should be in English (with clear, readable terms) so both teachers and students can utilize them.`;

    const response = await ai.models.generateContent({
      model: "gemini-3.5-flash",
      contents: prompt,
      config: {
        systemInstruction: "You are a professional educational curriculum architect and specialized test author. Generate beautiful, professional multiple choice exam tests. Ensure that for each question there is exactly one correct option. Keep options distinctive, realistic, and do not use generic text. Keep the explanation field detailed.",
        responseMimeType: "application/json",
        responseSchema: {
          type: Type.OBJECT,
          required: ["title", "subject", "durationMinutes", "difficulty", "questions"],
          properties: {
            title: { type: Type.STRING, description: "Professional name of the test, e.g. Data Structures Mastery Exam" },
            subject: { type: Type.STRING, description: "Broad subject category, e.g. Computer Science" },
            durationMinutes: { type: Type.INTEGER, description: "A realistic test limit in minutes (e.g. 5, 10, 15, or 20 minutes)" },
            difficulty: { type: Type.STRING, description: "Difficulty level: Easy, Medium, or Hard" },
            questions: {
              type: Type.ARRAY,
              description: "List of multiple-choice questions.",
              items: {
                type: Type.OBJECT,
                required: ["id", "questionText", "options", "correctOptionIndex", "explanation"],
                properties: {
                  id: { type: Type.STRING, description: "A unique alphanumeric ID like q1, q2" },
                  questionText: { type: Type.STRING, description: "The core question statement" },
                  options: {
                    type: Type.ARRAY,
                    description: "Exactly 4 options for the multiple choice",
                    items: { type: Type.STRING }
                  },
                  correctOptionIndex: { type: Type.INTEGER, description: "Index of the correct answer (0, 1, 2, or 3)" },
                  explanation: { type: Type.STRING, description: "Detailed description explaning why this is the correct answer" }
                }
              }
            }
          }
        }
      }
    });

    const responseText = response.text;
    if (!responseText) {
      throw new Error("Empty response from AI generation model");
    }

    const quizData = JSON.parse(responseText);
    return res.json({ test: quizData });

  } catch (error: any) {
    console.error("Gemini API Error during generation:", error);
    // Graceful fallback to prevent app crashing and keep developers happy
    const fallback = generateMockFallbackTest(topic, difficulty || "Medium", questionCount);
    return res.json({
      test: fallback,
      warning: "AI key failed or limit hit. Switched to automated template-generated test.",
      errorDetails: error.message
    });
  }
});

// Helper for Mock Fallback Test Generation
function generateMockFallbackTest(topic: string, difficulty: string, count: number) {
  const sanitizedTopic = topic.trim();
  const listQuestions = [];

  for (let i = 1; i <= count; i++) {
    listQuestions.push({
      id: `q_fallback_${i}`,
      questionText: `What is the primary architectural concept of ${sanitizedTopic} in relation to question state #${i}?`,
      options: [
        `Option A: Implements standard direct encapsulated memory arrays.`,
        `Option B: Configures decentralized loose component bindings dynamically.`,
        `Option C: Executes lazy loading via ChangeNotifier mechanisms.`,
        `Option D: None of the above models are correct.`
      ],
      correctOptionIndex: (i % 3),
      explanation: `Option ${(i % 3) === 0 ? "A" : (i % 3) === 1 ? "B" : "C"} is correct because in ${sanitizedTopic} state optimization requires explicit structured dependency injection hooks and binding cycles corresponding to question index #${i}.`
    });
  }

  return {
    id: `custom_${Date.now()}`,
    title: `${sanitizedTopic} Comprehensive Mock Test`,
    subject: sanitizedTopic,
    durationMinutes: count * 2,
    difficulty: difficulty,
    questions: listQuestions
  };
}

// 2. Integration with Vite (Development or Production build)
async function startApp() {
  if (process.env.NODE_ENV !== "production") {
    console.log("Booting server in DEVELOPMENT mode with Vite Middleware...");
    const vite = await createViteServer({
      server: { middlewareMode: true },
      appType: "spa",
    });
    app.use(vite.middlewares);
  } else {
    console.log("Serving server in PRODUCTION mode with compiled assets...");
    const distPath = path.join(process.cwd(), "dist");
    app.use(express.static(distPath));
    app.get("*", (req, res) => {
      res.sendFile(path.join(distPath, "index.html"));
    });
  }

  app.listen(PORT, "0.0.0.0", () => {
    console.log(`Express dev server running successfully at http://localhost:${PORT}`);
  });
}

startApp().catch((err) => {
  console.error("Failed to start custom server:", err);
});
